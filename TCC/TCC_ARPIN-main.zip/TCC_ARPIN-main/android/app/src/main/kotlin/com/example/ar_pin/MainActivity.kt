package com.example.ar_pin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
